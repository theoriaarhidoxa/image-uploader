import React, {useState, useRef} from 'react';
import {Link} from 'react-router-dom';
import Cloud from '../images/cloud-icon_on.svg';
import firebase from 'firebase/app';
import 'firebase/storage';

const firebaseConfig = {
    apiKey: "AIzaSyABsZayhyap7VemkqfhinX4gdRgXUEV-tw",
    authDomain: "imageuploader2-b3cb3.firebaseapp.com",
    projectId: "imageuploader2-b3cb3",
    storageBucket: "imageuploader2-b3cb3.appspot.com",
    messagingSenderId: "244612194682",
    appId: "1:244612194682:web:8572ebd8244e6e7930b6c3"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
} else {
    firebase.app();
}

const storage = firebase.storage();

const UploadMode = () => {

    const fileInput = useRef();
    const [previews, setPreviews] = useState([]);
    const [uploadStart, setUploadStart] = useState(false);

    const handleDialogOpening = () => {
        fileInput.current.click();
    };

    const handleFileSelection = e => {
        setPreviews([]);
        let {files} = e.target;
        files = Array.from(files);
        setPreviews(files.map((el, i) => {
            const obj = Object.assign(el, {});
            obj.id = new Date().getTime() + i;
            obj.uploadProgress = 0;
            return obj;
        }));

        files.forEach((el, i) => {
            const reader = new FileReader();

            reader.onload = async e => {
                const src = await e.target.result, timeStamp = await e.timeStamp;
                setPreviews(previews => previews.map((el, index) => {
                    if (i === index) {
                        const obj = Object.assign(el);
                        // [...spread] не работает для File, тот теряется
                        obj.src = src;
                        obj.timeStamp = timeStamp;
                        obj.order = i + 1;
                        return obj;
                    } else {
                        return el;
                    }
                }));
            };
            reader.readAsDataURL(el);
        });
    };

    const handleSelectionRemoval = id => {
        setPreviews(previews.filter(el => el.id !== id));
    };

    const handleDataSubmit = () => {
        setUploadStart(true);

        previews.forEach((file) => {
            const ref = storage.ref(`/upload/${file.name}`);
            const task = ref.put(file);
            const len = previews.length;

            task.on('state_changed', snapshot => {
                    const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                    const foundEl = previews.find(el => el.size === snapshot.totalBytes);
                    foundEl.uploadProgress = parseInt(progress);
                    setPreviews([...previews, foundEl].slice(0, len));
                }, e => {
                },
                () => {
                });
        });
    };

    const handleReset = () => {
        setPreviews([]);
        setUploadStart(false);
    };

    return (
        <>
            <input type='file' multiple ref={fileInput} onChange={handleFileSelection} accept='image/*'/>
            {previews.length === 0 && <h2><img src={Cloud} alt=''/>Начните добавлять изображения...</h2>}

            <div className='wrapper__buttons'>
                <input type='button' disabled={uploadStart} className='btn'
                       value={previews.length ? 'Повторить' : 'Начать'} onClick={handleDialogOpening}/>
                {previews.length > 0 &&
                <input type='button' disabled={uploadStart} onClick={handleDataSubmit} className='btn red'
                       value='Загрузить'/>}
                {uploadStart &&
                <input type='button' className='btn' value='Начать заново' onClick={handleReset}/>}
            </div>

            <div className='wrapper__previews' onClick={() => console.log(previews)}>
                {previews.sort((a, b) => a.order - b.order).map(el => {
                    return (
                        <div key={el.id} className='wrapper__previews-item'><img src={el.src} alt=''/>
                            {!uploadStart && <i onClick={() => handleSelectionRemoval(el.id)}/>}
                            <p className={uploadStart ? 'panel hiddenPanel' : 'panel'}>
                                <span>{el.name}</span><span>{`${(el.size / 1000).toFixed(1)} Kb`}</span>
                            </p>
                            {uploadStart && <p className='panel bluePanel'><span
                                style={el.uploadProgress === 100 ? {color: '#fff'} : null}>{el.uploadProgress}%</span><em
                                style={{'width': el.uploadProgress + '%'}}/></p>}
                        </div>
                    )
                })}
            </div>

            {uploadStart && <span className='fixedBottomRight'><Link to='/list'>Список загруженных файлов</Link></span>}
        </>
    );
};

export default UploadMode;
