import React, {useState, useEffect} from 'react';
import {Link} from "react-router-dom";
import firebase from 'firebase/app';
import 'firebase/storage';
import Loader from "../helpers/Loader";

const firebaseConfig = {
    apiKey: "AIzaSyABsZayhyap7VemkqfhinX4gdRgXUEV-tw",
    authDomain: "imageuploader2-b3cb3.firebaseapp.com",
    projectId: "imageuploader2-b3cb3",
    storageBucket: "imageuploader2-b3cb3.appspot.com",
    messagingSenderId: "244612194682",
    appId: "1:244612194682:web:8572ebd8244e6e7930b6c3"
};

// https://stackoverflow.com/questions/43331011/firebase-app-named-default-already-exists-app-duplicate-app
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
} else {
    firebase.app();
}

const storage = firebase.storage();


const ViewMode = () => {
    const [loading, setLoading] = useState(true);
    const [uploaded, setUploaded] = useState([]);
    const [emptyList, setEmptyList] = useState(false);

    useEffect(() => {
        handleListFetch();
    }, []);


    const handleListFetch = () => {
        const storageRef = storage.ref();
        const listRef = storageRef.child('/upload');

        listRef.listAll()
            .then((res) => {
                res.items.forEach((itemRef) => {
                    itemRef.getDownloadURL().then(url => {
                        setUploaded(uploaded => [...uploaded, url]);
                    }).catch(error => {
                        // Handle any errors
                    });
                });
                res.prefixes.forEach((folderRef) => {
                    console.log("folder", folderRef._delegate._location.path_.split('/')[1])// In my case:)

                });
            }).catch((error) => {
            // Uh-oh, an error occurred!
        }).finally(() => {
            setLoading(false);
        });
    };

    const handleFileRemove = (url, e) => {
        e.target.disabled = true;
        const fileRef = storage.refFromURL(url);

        fileRef.delete().then(() => {
            setUploaded(uploaded.filter(el => el !== url));
            if (uploaded.length < 2) {
                setEmptyList(true);
            }
        }).catch(function (error) {
            // Some Error occurred
        });
    };

    if (loading) {
        return <Loader />
    }

    return (
        <>
            {emptyList && <h2 style={{padding: '70px 0 30px 0'}}>Все ранее загруженные файлы удалены. Иным способом увидеть эту надпись не получится.</h2>}
            <div className='wrapper__filesList'>
                <table>
                    <tbody>
                    {uploaded.map(src => {
                        return (
                            <tr key={src} className='wrapper__filesList-item'>
                                <td><img src={src} alt='' /></td>
                                <td><a href={src} target='_blank' rel='noreferrer'>{src}</a></td>
                                <td><button className='btn' onClick={e => handleFileRemove(src, e)}>Удалить</button></td>
                            </tr>
                        )
                    })}
                    </tbody>

                </table>
            </div>


            <span className='fixedBottomRight'><Link to='/'>Вернуться к загрузчику</Link></span>
        </>
    );
};

export default ViewMode;
