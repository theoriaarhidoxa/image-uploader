import firebase from 'firebase/app';
import 'firebase/storage';

const firebaseConfig = {
    apiKey: "AIzaSyABsZayhyap7VemkqfhinX4gdRgXUEV-tw",
    authDomain: "imageuploader2-b3cb3.firebaseapp.com",
    projectId: "imageuploader2-b3cb3",
    storageBucket: "imageuploader2-b3cb3.appspot.com",
    messagingSenderId: "244612194682",
    appId: "1:244612194682:web:8572ebd8244e6e7930b6c3"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
} else {
    firebase.app();
}

const storage = firebase.storage();


export const fetchData = () => {
    return async dispatch => {
        const storageRef = storage.ref();
        const listRef = storageRef.child('/upload');
        dispatch({type: 'SET_EMPTY_LIST', payload: false});

        listRef.listAll()
            .then((res) => {
                res.items.forEach((itemRef) => {
                    itemRef.getDownloadURL().then(url => {
                        dispatch({type: 'FETCH_SINGLE_IMAGE', payload: url});
                    }).catch(error => {
                    });
                });
            })
            .catch((error) => {
            })
            .finally(() => {
                dispatch({type: 'SET_LOADING', payload: false});
            });
    }
};

export const removeItem = url => {
    return async dispatch => {
        const fileRef = storage.refFromURL(url);

        fileRef.delete().then(() => {
            dispatch({type: 'REMOVE_SINGLE_IMAGE', payload: url});
        });
    };
};

