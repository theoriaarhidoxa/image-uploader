const initialState = {
    loading: true,
    emptyList: false,
    images: []
};

export const imageReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'SET_EMPTY_LIST':
            return {...state, emptyList: action.payload, images: []};
        case 'SET_LOADING':
            return {...state, loading: action.payload};
        case 'FETCH_SINGLE_IMAGE':
            return {...state, images: [...state.images, action.payload]};
        case 'REMOVE_SINGLE_IMAGE':
            return {...state, images: state.images.filter(el => el !== action.payload)};
        default:
            return state;
    }
};
